package sockets.helloworld;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class MultiClientLauncher {
    static class ClientThread extends Thread {
        private final int clientId;

        public ClientThread(int clientId) {
            this.clientId = clientId;
        }

        @Override
        public void run() {
            try {
                Socket socket = new Socket("127.0.0.1", 6000);
                DataOutputStream output = new DataOutputStream(socket.getOutputStream());
                BufferedReader socketBufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                System.out.println("Client " + clientId + " connected to the server.");

                for (int i = 0; i < 10000; i++) {
                    output.writeBytes("Hello from client " + clientId + System.lineSeparator());
                    output.flush();
                    String response = socketBufferedReader.readLine();
                    System.out.println("Client " + clientId + " received: " + response);
                }

                output.close();
                socketBufferedReader.close();
                socket.close();

                System.out.println("Client " + clientId + " disconnected.");
            } catch (IOException e) {
                System.err.println("Client " + clientId + " encountered an error: " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        int numberOfClients = 5; // klienci
        for (int i = 1; i <= numberOfClients; i++) {
            new ClientThread(i).start();
        }
    }
}
