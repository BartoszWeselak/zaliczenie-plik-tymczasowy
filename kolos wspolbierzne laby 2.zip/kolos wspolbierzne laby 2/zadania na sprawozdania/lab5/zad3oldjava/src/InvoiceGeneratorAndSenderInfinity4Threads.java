import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class InvoiceGeneratorAndSenderInfinity4Threads {
    public static void main(String[] args) {
        ArrayList<Invoice> invoices = new ArrayList<>();
        LinkedList<Invoice> invoicesWithPdf = new LinkedList<>();
        final ReentrantLock lock = new ReentrantLock(true);
        final Condition createdInvoicePdf = lock.newCondition();
        AtomicInteger noInvoicesCreated = new AtomicInteger();
        AtomicInteger noPdfCreated = new AtomicInteger();
        AtomicInteger noEmailsSend = new AtomicInteger();

        // Thread to create invoices
        Runnable invoiceCreator = () -> {
            while (true) { // Infinite loop
                boolean acquired = false;
                try {
                    acquired = lock.tryLock(100, TimeUnit.MILLISECONDS);
                    if (acquired) {
                        Invoice i = Invoice.createRandomInvoice();
                        i.printJustCreated();
                        invoices.add(i);
                        System.out.println("Invoices created: " + noInvoicesCreated.incrementAndGet());
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    if (acquired)
                        lock.unlock();
                }
            }
        };

        // Start four threads for creating invoices
        for (int i = 0; i < 4; i++) {
            new Thread(invoiceCreator).start();
        }

        // Class for creating PDF
        class Pdf extends Thread {
            @Override
            public void run() {
                while (true) { // Infinite loop
                    boolean acquired = false;
                    try {
                        acquired = lock.tryLock();
                        if (acquired) {
                            if (!invoices.isEmpty()) {
                                Invoice first = invoices.get(0);
                                invoices.remove(0);
                                first.makeInvoicePdf();
                                invoicesWithPdf.addLast(first);
                                System.out.println("PDF created for invoice.");
                                createdInvoicePdf.signal();
                                noPdfCreated.incrementAndGet();
                            }
                        }
                    } finally {
                        if (acquired)
                            lock.unlock();
                    }
                }
            }
        }

        // Start two threads for creating PDFs
        new Pdf().start();
        new Pdf().start();

        // Thread for sending emails
        new Thread(() -> {
            while (true) { // Infinite loop
                boolean acquired = false;
                try {
                    acquired = lock.tryLock();
                    if (acquired) {
                        if (invoicesWithPdf.isEmpty()) {
                            System.out.println("I have to wait!");
                            createdInvoicePdf.await();
                        }
                        if (!invoicesWithPdf.isEmpty()) {
                            invoicesWithPdf.getFirst().sendEmail();
                            invoicesWithPdf.removeFirst();
                            System.out.println("Email sent. Total emails sent: " + noEmailsSend.incrementAndGet());
                        }
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    if (acquired)
                        lock.unlock();
                }
            }
        }).start();
    }
}
