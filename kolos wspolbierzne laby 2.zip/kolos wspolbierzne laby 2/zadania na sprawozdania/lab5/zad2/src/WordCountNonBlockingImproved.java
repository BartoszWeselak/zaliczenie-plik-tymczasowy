import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class WordCountNonBlockingImproved {
    public static void main(String[] args) throws Exception {
        String text = "This is some text. It is intended to be counted by threads.\n" +
                "Each thread will be taking a line and then will count words.\n" +
                "It is supposed to be faster than a standard, sequential way.\n" +
                "This example is non-blocking and should be different from\n" +
                "the previous one.\n";

        ArrayList<String> lines = new ArrayList<>(Arrays.asList(text.split("\n")));
        HashMap<String, AtomicInteger> wordsCounted = new HashMap<>();
        int numberOfThreads = 3;
        CyclicBarrier cb = new CyclicBarrier(numberOfThreads, () -> {
            // After all threads complete, print word counts.
            for (String word : wordsCounted.keySet()) {
                int count = wordsCounted.get(word).get();
                System.out.println(word + " has " + count + (count > 1 ? " occurrences." : " occurrence."));
            }
        });

        class Counter extends Thread {
            int begin, end;
            public Counter(int begin, int end) {
                this.begin = begin;
                this.end = end;
            }

            @Override
            public void run() {
                HashMap<String, AtomicInteger> localWordCount = new HashMap<>();
                for (int i = begin; i < end; i++) {
                    String line = lines.get(i);
                    System.out.println("I am thread " + this.getId() + " and I got line: " + line);
                    String[] splittedWords = line.split(" ");

                    // Count words locally in each thread
                    for (String word : splittedWords) {
                        localWordCount.putIfAbsent(word, new AtomicInteger(0));
                        localWordCount.get(word).incrementAndGet();
                    }
                }

                // After processing all lines, synchronize with global map
                synchronized (wordsCounted) {
                    for (String word : localWordCount.keySet()) {
                        wordsCounted.putIfAbsent(word, new AtomicInteger(0));
                        wordsCounted.get(word).addAndGet(localWordCount.get(word).get());
                    }
                }

                try {
                    cb.await();
                } catch (InterruptedException | BrokenBarrierException e) {
                    e.printStackTrace();
                }
            }
        }

        ExecutorService executor = Executors.newFixedThreadPool(numberOfThreads);
        // Divide work among threads
        executor.submit(new Counter(0, 2));
        executor.submit(new Counter(2, 3));
        executor.submit(new Counter(3, lines.size()));
        executor.shutdown();
    }
}
