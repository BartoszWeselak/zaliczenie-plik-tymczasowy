#include <ncurses.h> // biblioteka ncurses = new courses, da nam możliwość nieblokującego korzystania
// ze strumieni wejściowych
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <malloc.h>
#define BRIGHT_WHITE 15
char* local_buffer;
// struktura w której
// będziemy przechowywać
// 2 bufory, identyfikatory procesów i stan
// gotowości procesów
struct memory {
char buff1[100];
char buff2[100];
int size, size2;
int status, block, pid1, pid2;
};
// wskaźnik, w którym będziemy
// przechowywać strukturę
struct memory* shared_memory;
// pomocnicza funkcja, która wyczyści okno w razie
// gdy zabraknie w nim miejsca
void print_and_clear_screen_if_needed(char* s) {
int ok = printw(s);

if (ok == ERR) {
clear();
printw(s);
}
}
void handler(int signum)
{
// nadpisujemy handler dla sygnału
// SIGUSR2, będzie to wiadomość
// od pierwszego użytkownika czatu
// wiadomość będzie wysyłał inny proces
if (signum == SIGUSR2) {
// wiadomość od drugiego użytkownika
// chcemy napisać w innym kolorze
start_color();
init_pair(1, COLOR_BLUE, COLORS > 15 ? 15 : COLOR_WHITE);
init_pair(2, COLOR_BLACK, COLORS > 15 ? 15 : COLOR_WHITE);
attron(COLOR_PAIR(1));
int ok;
print_and_clear_screen_if_needed("\nReceived From User1: ");
// wypisujemy wiadomość od drugiego usera
printw(shared_memory->buff1);
attroff(COLOR_PAIR(1));
attron(COLOR_PAIR(2));
// "zerujemy" bufor tego usera, żeby ponownie był pusty
shared_memory->buff1[0] = '\0';
memset(shared_memory->buff1, 0, 100);
// ponawiamy label użytkownika
print_and_clear_screen_if_needed("\nUser2: ");
// gdyby user wcześniej zaczął coś pisać, ale
// nie zdążył tego wysłać i jednocześnie inny user
// przerwał ten proces, przywracamy na ekran tę wiadomość
printw(local_buffer);
// shared_memory->block = 0;
}
}
int main() {
// pobieramy identyfikator procesu
// proszę zwrócić uwagę, że nie wywołano
// fork; jednak ponieważ każdy proces ma pid
// to możemy je odczytać
int pid = getpid();
// identyfikator bloku pamięci
int shmid;
// arbitralnie dobrany identyfikator bloku pamięci, wspólny
// dla obydwu procesów
int key = 123456;
// tworzymy pamięć współdzieloną, do odczytu i zapisu
shmid = shmget(key, sizeof(struct memory), IPC_CREAT | 0666);
// dowiązujemy do wskaźnika shared_memory wcześniej zaalokowany blok pamięci
shared_memory = (struct memory*)shmat(shmid, NULL, 0);
// zapisujemy w strukturze identyfikator tego procesu
// oraz status
shared_memory->pid2 = pid;
// shared_memory->status = 0;
shared_memory->size2 = 0;
// shared_memory->block = 0;
// definiujemy handler dla sygnału SIGUSR2
signal(SIGUSR2, handler);
// tutaj tworzymy "okno" zarządzane przez bibliotekę ncurses
WINDOW *w;
char c;
// inicjujemy ekran
w = initscr();
// wejście będzie pobierane w trybie nieblokującym
nodelay(w, 1);
// wyłączamy domyślne zachowanie terminala

raw();
noecho();
//timeout(3000);
wclrtoeol(w);
local_buffer = malloc(100 * sizeof(char));
int size = 0;
// piszemy label usera
printw("%s", "User2: ");
for (;;) {
// pobieramy pojedynczy znak ze standardowego wejścia
c = getch();
// jeżeli wciśnięto esc albo znak q od quit kończymy działanie
// programu
if (c == 'q' || (int) c == 27) {
shmdt((void*)shared_memory);
// usuwamy blok pamięci współdzielonej
// robi to tylko jeden proces
shmctl(shmid, IPC_RMID, NULL);
break; // wyjście z pętli nieskończonej, koniec wykonywania programu
}
// jeżeli znak nie jest znakiem sterującym
// dodajemy go do bufora
if (c != ERR && (int) c != 10)
{
addch(c); // wypisujemy znak na ekran
local_buffer[size] = c;
size++;
//shared_memory->buff2[shared_memory->size2] = c;
//shared_memory->size2++;
}
// jeżeli wciśnięto enter (return)
if ((int) c == 10) {
local_buffer[size] = '\n';
memcpy(shared_memory->buff2, local_buffer,size);
shared_memory->size2 = 0;
size = 0;
memset(local_buffer, 0, 100);
// wypisuejmu label usera
print_and_clear_screen_if_needed("\nUser2: ");
// przesyłamy sygnał do drugiego procesu
kill(shared_memory->pid1, SIGUSR1);
}
refresh();
}
// odświeżamy terminal
refresh();
// zwracamy sterowanie terminalem do stanu wyjściowego
// czyli biblioteka ncurses przestaje kontrolować terminal
endwin();
}
