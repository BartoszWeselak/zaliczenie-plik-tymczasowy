#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

int main(void) {
    int p[2]; // pipe
    pid_t process; // pid procesu
    char buffer[1024]; // bufor do odczytu danych z pipe'a
    int even_count = 0; // licznik liczb parzystych

    // Tworzenie pipe'a
    if (pipe(p) == -1) {
        perror("pipe failed");
        exit(1);
    }

    // Tworzenie procesu potomnego
    if ((process = fork()) == 0) {
        // Proces potomny
        dup2(p[1], STDOUT_FILENO); // Przekierowanie standardowego wyjścia do pipe'a
        close(p[0]); // Zamknięcie nieużywanego końca do odczytu

        // Uruchomienie Pythona z podaną komendą
        execlp("python3", "python3", "-c", "for i in range(10): print(i)", NULL);

        // W przypadku błędu
        perror("execlp python3 failed");
        exit(1);
    } else if (process == -1) {
        perror("fork failed");
        exit(1);
    }

    // Proces rodzica
    close(p[1]); // Zamknięcie końca do zapisu pipe'a

    // odczytywanie danych z pipe'a
    int bytes_read = read(p[0], buffer, sizeof(buffer) - 1);
    if (bytes_read == -1) {
        perror("read failed");
        exit(1);
    }
    buffer[bytes_read] = '\0';

    close(p[0]); // Zamknięcie końca do odczytu pipe'a

    // Oczekiwanie na zakończenie procesu potomnego
    wait(NULL);

    // Aliczenie liczb parzystych
    char *token = strtok(buffer, "\n");
    while (token != NULL) {
        int number = atoi(token);
        if (number % 2 == 0) {
            even_count++;
        }
        token = strtok(NULL, "\n");
    }

    // Wypisanie wyniku
    printf(" liczby parzyste: %d\n", even_count);

    return 0;
}
