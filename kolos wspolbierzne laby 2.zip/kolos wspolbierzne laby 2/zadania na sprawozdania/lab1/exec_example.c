#include <stdlib.h> // biblioteka standardowa języka C
#include <unistd.h> // biblioteka zawierająca api biblioteki POSIX
#include <string.h>
#include <stdio.h> // standard input output library
/*
demonstacja jednego z wariantów funkcji exec
utworzony zostanie proces innego programu
po czym na ekran zostanie wypisany rezultat
jego działania
*/
int main() {
printf("%s\n", "I will never be printed!");

char *myargs[3]; // 3 elementowa tablica wskaźników na typ char
myargs[0] = strdup("/usr/bin/wc"); // wywołamy program wc (word count), zatem podajemy jego nazwę jako 1. argument
myargs[1] = strdup("exec_example.c"); // nazwa pliku, gdzie chcemy zliczyć słowa, zliczamy słowa wystepujące wtym pliku!, 2. argument
myargs[2] = NULL; // oznaczenie końca tablicy, musi tak być zgodnie z dokumentacją
execv(myargs[0], myargs); // uruchamiamy proces wc, z argumentem exec_example.c
printf("%s", "I will never be printed!");
exit(0); // kończymy wykonanie programu z poprawnym statusem wykonania;
// tutaj jednak ta linia nigdy nie zostanie wykonana
}
/*
Czy potrafisz wytłumaczyć dlaczego nie zostanie wypisana linia z komunikatem: „I
will never be printed!”?
procs zostal wywolany przed print

Zamień wywołanie funkcji execvp na execv, ale pozostaw argumenty bez zmian. Co się
stało? Czy wiesz jak można sprawić aby ta wersja programu działała tak jak
poprzednia?
*/
