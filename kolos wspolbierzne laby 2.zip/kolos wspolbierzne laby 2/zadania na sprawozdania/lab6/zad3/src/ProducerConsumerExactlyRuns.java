import java.util.LinkedList;
import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class ProducerConsumerExactlyRuns {
    static LinkedList<String> buffer = new LinkedList<>();
    static final int BUFFER_SIZE = 20;
    static ReentrantLock lock = new ReentrantLock(true);
    static Condition bufferNotFull = lock.newCondition();
    static Condition bufferNotEmpty = lock.newCondition();

    public static void main(String[] args) {
        class Producer extends Thread {
            private String name;
            private int itemsToProduce;

            public Producer(String name, int itemsToProduce) {
                this.name = name;
                this.itemsToProduce = itemsToProduce;
            }

            @Override
            public void run() {
                int itemsProduced = 0;
                while (itemsProduced < itemsToProduce) {
                    lock.lock();
                    if (buffer.size() == BUFFER_SIZE) {
                        try {
                            bufferNotFull.await();
                            System.out.println("Producer " + name + " is waiting, full buffer");
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Random r = new Random();
                        String[] words = {"aaa", "bbb", "ccc", "ddd", "eee", "fff"};
                        String s = words[r.nextInt(words.length)];
                        System.out.println("Producer " + name + " produces: " + s);
                        buffer.addLast(s);
                        bufferNotEmpty.signal();
                        itemsProduced++;
                    }
                    lock.unlock();
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("Producer " + name + " has finished producing.");
            }
        }

        class Consumer extends Thread {
            private String name;
            private int itemsToConsume;

            public Consumer(String name, int itemsToConsume) {
                this.name = name;
                this.itemsToConsume = itemsToConsume;
            }

            @Override
            public void run() {
                int itemsConsumed = 0;
                while (itemsConsumed < itemsToConsume) {
                    lock.lock();
                    if (buffer.size() == 0) {
                        System.out.println("Consumer " + name + " is waiting, empty buffer");
                        try {
                            bufferNotEmpty.await();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        String elem = buffer.getFirst();
                        System.out.println("Consumer " + name + " consumes: " + elem + " and processes it to: "
                                + elem.toUpperCase());
                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        buffer.removeFirst();
                        bufferNotFull.signal();
                        itemsConsumed++;
                    }
                    lock.unlock();
                }
                System.out.println("Consumer " + name + " has finished consuming.");
            }
        }

        new Producer("I", 1).start();
        new Producer("II", 3).start();
        new Consumer("I", 2).start();
        new Consumer("II", 2).start();
    }
}
