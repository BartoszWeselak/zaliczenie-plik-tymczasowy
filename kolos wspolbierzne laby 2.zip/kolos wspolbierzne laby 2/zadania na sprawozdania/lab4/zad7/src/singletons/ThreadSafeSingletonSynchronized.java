package singletons;
public class ThreadSafeSingletonSynchronized {
    private static ThreadSafeSingletonSynchronized instance;
    private String value;
    private int counter;
    private ThreadSafeSingletonSynchronized(String value) {
// The following code emulates slow initialization.
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        this.value = value;
        this.counter = 0;
    }
    public static synchronized ThreadSafeSingletonSynchronized getInstance(String value) {
        if (instance == null) {
            instance = new ThreadSafeSingletonSynchronized(value);
        }
        return instance;
    }
    public String getValue() {
        return value;
    }
    public void someMethod() {
        counter++;
    }
    public int getCounter() {
        return counter;
    }
}