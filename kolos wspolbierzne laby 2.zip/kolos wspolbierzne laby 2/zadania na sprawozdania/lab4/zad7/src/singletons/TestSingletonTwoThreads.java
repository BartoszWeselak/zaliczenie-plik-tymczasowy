package singletons;
public class TestSingletonTwoThreads {
    public static void main(String [] args) {
        class One extends Thread {
            @Override
            public void run() {
                SequentialSingleton singleton = SequentialSingleton.getInstance("1");
                System.out.println(singleton);
                System.out.println("Singleton value: " + singleton.getValue());
                System.out.println("Singleton counter: " + singleton.getCounter());
            }
        }
        new One().start();
        class Two extends Thread {
            @Override
            public void run() {
                SequentialSingleton singleton2 = SequentialSingleton.getInstance("2");
                System.out.println(singleton2);
                System.out.println("Singleton value: " + singleton2.getValue());
                System.out.println("Singleton counter: " + singleton2.getCounter());
            }
        }
        new Two().start();
    }
}