package singletons;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class TestSingletonTwoThreadsDCL {
    public static void main(String [] args) {
        class One extends Thread {
            @Override
            public void run() {
                ThreadSafeSingletonDoubleCheckedLocking singleton =
                        ThreadSafeSingletonDoubleCheckedLocking.getInstance("1");
                System.out.println(singleton);
                System.out.println("Singleton value (from Thread 1): " + singleton.getValue());
                System.out.println("Singleton counter (from Thread 1): " + singleton.getCounter());
            }
        }
        class Two extends Thread {
            @Override
            public void run() {
                ThreadSafeSingletonDoubleCheckedLocking singleton2 =
                        ThreadSafeSingletonDoubleCheckedLocking.getInstance("2");
                System.out.println(singleton2);
                System.out.println("Singleton value (from Thread 2): " + singleton2.getValue());
                System.out.println("Singleton counter (from Thread 2): " + singleton2.getCounter());
            }
        }
        ExecutorService executor = Executors.newFixedThreadPool(5);
        executor.submit(new One());
        executor.submit(new Two());
        executor.shutdown();
    }
}