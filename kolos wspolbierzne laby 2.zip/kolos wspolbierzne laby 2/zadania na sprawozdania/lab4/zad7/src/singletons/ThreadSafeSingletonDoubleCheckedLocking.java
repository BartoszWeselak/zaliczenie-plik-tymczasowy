package singletons;
public class ThreadSafeSingletonDoubleCheckedLocking {
    private static volatile ThreadSafeSingletonDoubleCheckedLocking instance;
    private String value;
    private int counter;
    private ThreadSafeSingletonDoubleCheckedLocking(String value) {
// The following code emulates slow initialization.
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        this.value = value;
        this.counter = 0;
    }
    public static ThreadSafeSingletonDoubleCheckedLocking getInstance(String value) {
        ThreadSafeSingletonDoubleCheckedLocking reference = instance;
        if (reference != null) {
            return reference;
        }
        synchronized(ThreadSafeSingletonDoubleCheckedLocking.class) {
            if (instance == null) {
                instance = new ThreadSafeSingletonDoubleCheckedLocking(value);
            }
            return instance;
        }
    }
    public String getValue() {
        return value;
    }
    public int getCounter() {
        return counter;
    }
}