package singletons;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class TestSingletonTwoThreadsSynchronized {
    public static void main(String [] args) {
        class One extends Thread {
            @Override
            public void run() {
                ThreadSafeSingletonSynchronized singleton =
                        ThreadSafeSingletonSynchronized.getInstance("1");
                System.out.println(singleton);
                System.out.println("Singleton value: " + singleton.getValue());
                System.out.println("Singleton counter: " + singleton.getCounter());
            }
        }
        class Two extends Thread {
            @Override
            public void run() {
                ThreadSafeSingletonSynchronized singleton2 =
                        ThreadSafeSingletonSynchronized.getInstance("2");
                singleton2.someMethod();
                System.out.println(singleton2);
                System.out.println("Singleton value: " + singleton2.getValue());
                System.out.println("Singleton counter: " + singleton2.getCounter());
            }
        }
        ExecutorService executor = Executors.newFixedThreadPool(20);
        executor.submit(new One());
        executor.submit(new Two());
        executor.shutdown();
    }
}