package singletons;
public class SequentialSingleton {
    private static SequentialSingleton instance;
    private String value;
    private int counter;
    private SequentialSingleton(String value) {
// Emulacja powolnej inicjalizacji obiektu
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        this.value = value;
        this.counter = 0;
    }
    public static SequentialSingleton getInstance(String value) {
        if (instance == null) {
            instance = new SequentialSingleton(value);
        }
        return instance;
    }
    public String getValue() {
        return value;
    }
    public void someMethod() {
        counter++;
    }
    public int getCounter() {
        return counter;
    }
}