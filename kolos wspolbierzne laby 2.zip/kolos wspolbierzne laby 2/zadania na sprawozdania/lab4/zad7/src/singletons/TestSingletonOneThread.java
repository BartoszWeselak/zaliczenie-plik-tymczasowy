package singletons;
public class TestSingletonOneThread {
    public static void main(String [] args) {
        SequentialSingleton singleton = SequentialSingleton.getInstance("1");
        System.out.println(singleton);
        System.out.println("Singleton value: " + singleton.getValue());
        System.out.println("Singleton counter: " + singleton.getCounter());
        SequentialSingleton singleton2 = SequentialSingleton.getInstance("2");
        System.out.println(singleton2);
        System.out.println("Singleton value: " + singleton2.getValue());
        System.out.println("Singleton counter: " + singleton2.getCounter());
    }
}