public class ThreadHelloWorld {
    public static void main(String [] args) {
        HelloThread helloRunnable = new HelloThread(Boolean.FALSE);
        WorldThread worldRunnable = new WorldThread(Boolean.FALSE);

        Thread helloThread = new Thread(helloRunnable);
        Thread worldThread = new Thread(worldRunnable);

        worldThread.start();
        helloThread.start();
    }
}