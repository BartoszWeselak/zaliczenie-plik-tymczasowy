public class HelloThread implements Runnable {
    private Boolean waitForHello;
    public HelloThread(Boolean waitForHello) {
        this.waitForHello = waitForHello;
    }
    @Override
    public void run() {
        synchronized (waitForHello) {
            System.out.print("Hello");
            waitForHello.notify();
        }
    }
}