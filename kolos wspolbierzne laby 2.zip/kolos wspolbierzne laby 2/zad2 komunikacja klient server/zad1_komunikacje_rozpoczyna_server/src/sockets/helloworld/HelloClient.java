package sockets.helloworld;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class HelloClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("127.0.0.1", 6000);
        System.out.println("Connected to server: " + socket.getRemoteSocketAddress());

        // Odczytanie wiadomości od serwera
        BufferedReader socketBufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String serverMessage = socketBufferedReader.readLine();
        System.out.println("Server says: " + serverMessage);

        // Wysłanie odpowiedzi do serwera
        DataOutputStream output = new DataOutputStream(socket.getOutputStream());
        output.writeBytes("Hello from client!\n");
        output.flush();

        // Zamykanie połączenia
        output.close();
        socketBufferedReader.close();
        socket.close();
    }
}
