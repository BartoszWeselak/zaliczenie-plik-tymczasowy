package sockets.helloworld;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class HelloClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("127.0.0.1", 6000);
        System.out.println("Connected to server: " + socket.getRemoteSocketAddress());

        BufferedReader socketBufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        DataOutputStream output = new DataOutputStream(socket.getOutputStream());

        // Klient odbiera i wysyła cztery wiadomości
        for (int i = 1; i <= 4; i++) {
            // Odczytanie wiadomości od serwera
            String serverMessage = socketBufferedReader.readLine();
            System.out.println("Server says: " + serverMessage);

            // Wysłanie odpowiedzi do serwera
            output.writeBytes("Message " + i + " from client!\n");
            output.flush();
        }

        // Zamykanie połączenia
        output.close();
        socketBufferedReader.close();
        socket.close();
    }
}
