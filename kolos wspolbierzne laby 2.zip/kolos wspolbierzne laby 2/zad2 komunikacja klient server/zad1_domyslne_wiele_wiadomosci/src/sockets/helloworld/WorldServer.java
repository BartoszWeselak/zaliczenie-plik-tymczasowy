package sockets.helloworld;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class WorldServer {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(6000);
        System.out.println("Started server at: " + serverSocket.getLocalSocketAddress());

        Socket connection = serverSocket.accept();
        System.out.println("Client connected: " + connection.getInetAddress());

        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        DataOutputStream dataOutputStream = new DataOutputStream(connection.getOutputStream());

        String clientMessage;
        while ((clientMessage = br.readLine()) != null) { // Odbieranie wiadomości od klienta
            System.out.println("Client sends: " + clientMessage);

            // Wysłanie odpowiedzi do klienta
            String serverResponse = "Server received: " + clientMessage;
            dataOutputStream.writeBytes(serverResponse + "\n");
            dataOutputStream.flush();

            // Jeśli klient wysyła "exit", zamykamy połączenie
            if (clientMessage.equalsIgnoreCase("exit")) {
                System.out.println("Client disconnected.");
                break;
            }
        }

        dataOutputStream.close();
        br.close();
        connection.close();
        serverSocket.close();
    }
}