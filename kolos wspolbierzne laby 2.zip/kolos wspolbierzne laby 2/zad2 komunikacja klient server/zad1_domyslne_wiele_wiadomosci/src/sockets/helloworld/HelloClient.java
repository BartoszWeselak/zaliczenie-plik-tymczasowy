
package sockets.helloworld;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class HelloClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("127.0.0.1", 6000);
        System.out.println("Connected to the server.");

        DataOutputStream output = new DataOutputStream(socket.getOutputStream());
        BufferedReader socketBufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        Scanner scanner = new Scanner(System.in);

        String userInput;
        while (true) {
            output.writeBytes("Test" + "\n");
            // Wprowadzanie wiadomości przez użytkownika
            System.out.print("Enter a message (type 'exit' to quit): ");
            userInput = scanner.nextLine();
            output.writeBytes(userInput + "\n");
            output.flush();

            // Jeśli użytkownik wysyła "exit", zamykamy połączenie
            if (userInput.equalsIgnoreCase("exit")) {
                System.out.println("Disconnected from the server.");
                break;
            }

            // Odbieranie odpowiedzi od serwera
            String serverResponse = socketBufferedReader.readLine();
            System.out.println("Server responds: " + serverResponse);
        }

        output.close();
        socketBufferedReader.close();
        socket.close();
        scanner.close();
    }
}
